

import addImage from "./images/addImage.png"
import logoLight from "./images/owl-logo.png"

export const images = {
  addImage,
  logoLight
}