


import React from 'react'

const SignupPage = () => {
  return (
    <div className=''>
      
    </div>
  )
}

export default SignupPage
