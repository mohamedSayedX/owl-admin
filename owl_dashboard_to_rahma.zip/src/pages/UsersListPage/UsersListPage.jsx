import React, {useEffect} from "react";
import PageContentLayout from "../../layouts/PageContentLayout/PageContentLayout";
import useGetListOfUsers from "../../customHooks/ApiHooks/usersHooks/useGetListOfUsers";
import {Avatar} from "antd";

const UsersListPage = () => {
  const {handleGetListOfUsers, loading} = useGetListOfUsers();

  const columns = [
    {
      title: "User Image",
      dataIndex: "user_image",
      key: "user_image",
      render: (imageUrl, row) => <Avatar src={imageUrl} />,
    },
    {
      title: "User ID",
      dataIndex: "user_id",
      key: "user_id",
    },
    {
      title: "User Name",
      dataIndex: "user_name",
      key: "user_name",
    },
    {
      title: "User Phone",
      dataIndex: "user_phone",
      key: "user_phone",
    },
    {
      title: "User Email",
      dataIndex: "user_email",
      key: "user_email",
    },
  ];

  useEffect(() => {
    handleGetListOfUsers();
  }, []);

  return (
    <div>
      <PageContentLayout
        pageTitle={"Users list"}
        description={"OWL website users list"}
        // description={"in home banners"}
        AddBtn={false}
        columns={columns}
        table={true}
      ></PageContentLayout>
    </div>
  );
};

export default UsersListPage;
