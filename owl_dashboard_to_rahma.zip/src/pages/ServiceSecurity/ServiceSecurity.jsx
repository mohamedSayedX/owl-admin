import React, {useEffect} from "react";
import PageContentLayout from "../../layouts/PageContentLayout/PageContentLayout";
import {useNavigate} from "react-router-dom";
import useGetServices from "./../../customHooks/ApiHooks/ServicesHooks/useGetServices";
import TableImage from "../../utils/TableImage/TableImage";
import ActivationBadge from "../../utils/ActivationBadge/ActivationBadge";

const ServiceSecurity = () => {
  const navigate = useNavigate();

  const {handleGetServices, services, loading} = useGetServices();

  useEffect(() => {
    handleGetServices();
  }, []);

  const columns = [
    {
      title: "Icon",
      dataIndex: "service_icon",
      key: "service_icon",
      render: (service_icon) => <TableImage src={service_icon} />,
    },

    {
      title: "Image",
      dataIndex: "service_image",
      key: "service_image",
      render: (service_image) => <TableImage src={service_image} />,
    },

    {
      title: "Activation ",
      dataIndex: "isActive",
      key: "isActive",
      render: (link, row) => <ActivationBadge isActive={row?.isActive} />,
    },
  ];

  return (
    <PageContentLayout
      pageTitle={"Service Security"}
      description={""}
      AddBtn={true}
      loading={loading}
      columns={columns}
      data={loading ? [] : services}
      onAddBtnClick={() => navigate("/services-security/add")}
    ></PageContentLayout>
  );
};

export default ServiceSecurity;
