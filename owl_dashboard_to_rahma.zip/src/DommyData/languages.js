




const  languages = [
  {
    id: 1,
    lable: "English",
    value: "en",
    selected: true,
  },
  {
    id: 2,
    lable: "Spanish",
    value: "es",
  },
  {
    id: 3,
    lable: "Indian",
    value: "in",
  },
];



export default languages