import React, {useState} from "react";
import axiosInstance from "./../../../API/axiosInstance";
import axios from "axios";

const useGetListOfUsers = () => {
  const [loading, setLoading] = useState(false);
  
  const handleGetListOfUsers = async () => {
    setLoading(true);
    await axiosInstance
      .get("/user/list_website_users")
      .then((res) => {
        console.log(res);
      })
      .catch((e) => console.log(e))
      .finally(() => {
        setLoading(false);
      });
  };

  return {handleGetListOfUsers, loading};
};

export default useGetListOfUsers;
