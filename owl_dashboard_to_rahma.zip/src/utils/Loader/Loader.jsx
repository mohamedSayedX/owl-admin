import React from "react";
import "./style.css";
const Loader = () => {
  return (
    <div className="flex">

    <div class='__loader mx-auto'>
      <label>loading...</label>
      <div class='__loading'></div>
    </div>
    </div>
  );
};

export default Loader;
